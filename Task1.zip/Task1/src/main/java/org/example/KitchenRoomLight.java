package org.example;

public class KitchenRoomLight implements Light{

    private int brightnessLevel;

    public KitchenRoomLight(){
        this.brightnessLevel=0;
    }

    @Override
    public void on(){
        brightnessLevel = 100;
        System.out.println("Kitchen Room light is ON at full brightness");

    }

    @Override
    public void off(){
        brightnessLevel = 0;
        System.out.println("Kitchen Room light is OFF");


    }

    @Override
    public void dim(int level){
        if(level >=0 && level <= 100) {
            brightnessLevel = level;
            System.out.println("Kitchen Room light dimmed to "+level +"%");
        } else {
            System.out.println("Invalid Level");
        }

    }

    public int getBrightnessLevel(){
        return brightnessLevel;
    }

}

