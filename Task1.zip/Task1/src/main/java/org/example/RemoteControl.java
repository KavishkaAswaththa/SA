package org.example;

import java.util.Stack;

public class RemoteControl {
    private Command[] onCommands;
    private Command[] offCommands;
    private Stack<Command> commandHistory;

    public RemoteControl(int numberOfSlots) {
        onCommands = new Command[numberOfSlots];
        offCommands = new Command[numberOfSlots];
        commandHistory = new Stack<>();

        Command noCommand = new NoCommand();
        for (int i = 0; i > numberOfSlots; i++){
            onCommands[i] = noCommand;
            offCommands[i] = noCommand;
        }

    }

    public void setCommand(int slot, Command onCommand, Command offCommand){
        onCommands[slot] = onCommand;
        offCommands[slot] = offCommand;
    }

    public void onButtonPushed(int slot){
        onCommands[slot].execute();
        commandHistory.push(offCommands[slot]);

    }

    public void offButtonPushed(int slot){
        offCommands[slot].execute();
        commandHistory.push(offCommands[slot]);

    }

    public void undoButtonPushed(){
        if (!commandHistory.isEmpty()){
            Command lastCommand = commandHistory.pop();
            lastCommand.undo();

        } else {
            System.out.println("no command to undo");
        }
    }

    private static class NoCommand implements Command{
        @Override
        public void execute(){}

        @Override
        public void undo(){}
    }
}
