package org.example;

public class LightDimCommand implements Command{
    private Light light;
    private int previousLevel;
    private int dimLevel;

    public LightDimCommand(Light light,int dimLevel){
        this.light = light;
        this.dimLevel = dimLevel;
    }

    @Override
    public void execute(){
        previousLevel = light instanceof KitchenRoomLight ? ((KitchenRoomLight) light).getBrightnessLevel():
                light instanceof LivingRoomLight ? ((LivingRoomLight) light).getBrightnessLevel():0;
        light.dim(dimLevel);


    }

    @Override
    public void undo(){
        light.dim(previousLevel);

    }

}
