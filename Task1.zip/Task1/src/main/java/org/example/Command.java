package org.example;

public interface Command {
    void execute();
    void undo();
}
